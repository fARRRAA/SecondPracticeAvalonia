using System;
using Srez.Data;

namespace Srez.Services
{
    /// <summary>
    /// Утилита для расчёта количества продукции, получаемой при использовании заданного количества материала.
    /// </summary>
    public static class ProductionCalculator
    {
        /// <summary>
        /// Рассчитать целое количество продукции, получаемой при использовании указанного количества сырья.
        /// Правила:
        /// - Количество сырья на одну единицу продукции = param1 * param2 * productType.Coefficient
        /// - Учитывается процент потерь сырья (materialType.LossPercentage) -- требуемое количество увеличивается
        /// - Возвращается целая часть от (usedMaterialAmount / requiredPerUnitWithLoss)
        /// - При неверных входных данных (несуществующие типы, неположительные параметры и т.п.) возвращается -1
        /// </summary>
        /// <param name="productTypeId">Идентификатор типа продукции (int)</param>
        /// <param name="materialTypeId">Идентификатор типа материала (int)</param>
        /// <param name="usedMaterialAmount">Количество используемого сырья (целое число, >=0)</param>
        /// <param name="param1">Параметр продукции 1 (double, >0)</param>
        /// <param name="param2">Параметр продукции 2 (double, >0)</param>
        /// <returns>Целое количество получаемой продукции или -1 при ошибке</returns>
        public static int CalculateProducedQuantity(int productTypeId, int materialTypeId, int usedMaterialAmount, double param1, double param2)
        {
            try
            {
                // Валидация входных данных
                if (productTypeId <= 0 || materialTypeId <= 0) return -1;
                if (usedMaterialAmount < 0) return -1;
                if (!(param1 > 0.0) || !(param2 > 0.0)) return -1;

                using var db = new AppDbContext();

                var productType = db.ProductTypes.Find(productTypeId);
                if (productType == null) return -1;

                var materialType = db.MaterialTypes.Find(materialTypeId);
                if (materialType == null) return -1;

                // Переводим параметры в decimal для точности финансовых/массовых расчётов
                decimal p1 = Convert.ToDecimal(param1);
                decimal p2 = Convert.ToDecimal(param2);

                // Коэффициент типа продукции (decimal в модели)
                decimal coeff = productType.Coefficient;

                // Количество сырья на одну единицу продукции (без учёта потерь)
                decimal perUnit = p1 * p2 * coeff;

                if (perUnit <= 0m)
                {
                    return -1;
                }

                // Процент потерь по типу материала (например, 5.5 означает +5.5%)
                decimal lossPct = materialType.LossPercentage;

                // Коэффициент учета потерь (1 + lossPct/100)
                decimal lossFactor = 1m + (lossPct / 100m);

                // Необходимое количество сырья на одну продукцию с учётом потерь
                decimal requiredPerUnitWithLoss = perUnit * lossFactor;

                if (requiredPerUnitWithLoss <= 0m)
                {
                    return -1;
                }

                // Рассчитываем, сколько целых единиц продукции можно получить из имеющегося сырья
                decimal available = Convert.ToDecimal(usedMaterialAmount);

                decimal producedDecimal = Math.Floor(available / requiredPerUnitWithLoss);

                if (producedDecimal < 0m) return 0;

                // Ограничиваем значение диапазоном int
                if (producedDecimal > int.MaxValue) return int.MaxValue;

                return (int)producedDecimal;
            }
            catch
            {
                // При любой непредвиденной ошибке возвращаем -1 согласно требованиям
                return -1;
            }
        }
    }
}
